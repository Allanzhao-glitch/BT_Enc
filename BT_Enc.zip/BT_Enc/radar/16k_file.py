
import os
import random
import string

# 设置目标文件大小为16KB（16 * 1024 bytes）
target_size = 5*1024

# 创建一个用于存储随机文本的列表
random_text = []

# 生成随机文本，直到达到或超过目标大小
while True:
    # 每次添加100个随机字符到列表中
    random_text.append(''.join(random.choices(string.ascii_letters + string.digits, k=100)))
    # 将列表中的字符串连接成一个大的字符串，并计算其字节大小
    text_bytes = ''.join(random_text).encode('utf-8')
    # 如果文本大小达到或超过目标大小，则退出循环
    if len(text_bytes) >= target_size:
        break

    # 截取文本以确保它正好是16KB（如果需要的话）
if len(text_bytes) > target_size:
    text_bytes = text_bytes[:target_size]

# 将文本写入文件
with open('16k_file.txt', 'wb') as f:
    f.write(text_bytes)

# 验证文件大小
print(f"File size: {os.path.getsize('16k_file.txt')} bytes")
