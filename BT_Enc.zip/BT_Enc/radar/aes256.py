from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import binascii


# HEX 编码函数：将字节数组编码为十六进制字符串
def hex_encode(data: bytes) -> str:
    return binascii.hexlify(data).decode('utf-8')


# HEX 解码函数：将十六进制字符串解码为字节数组
def hex_decode(hex_str: str) -> bytes:
    return binascii.unhexlify(hex_str)


# AES-256 CBC 模式加密函数
def aes256_encrypt(plaintext: bytearray, key: bytes, iv: bytes) -> str:
    """

    :rtype: object
    """
    cipher = AES.new(key, AES.MODE_CBC, iv)
    # 对明文进行 PKCS7 填充
    padded_data = pad(plaintext, AES.block_size)
    ciphertext = cipher.encrypt(padded_data)
    # 返回 HEX 编码结果
    return hex_encode(ciphertext)


# AES-256 CBC 模式解密函数
def aes256_decrypt(hex_input, key, iv):
    # 将十六进制字符串转换回字节
    ciphertext = binascii.unhexlify(hex_input)

    # 创建一个AES cipher对象
    cipher = AES.new(key, AES.MODE_CBC, iv)

    # 解密并去除填充
    plaintext_padded = cipher.decrypt(ciphertext)
    plaintext = unpad(plaintext_padded, AES.block_size)
    return plaintext


def aes256_gcm_encrypt(input_text: bytearray, key: bytes, iv: bytes, aad: bytes = None):
    aesgcm = AESGCM(key)
    data = input_text

    # 加密并生成认证标签
    ciphertext = aesgcm.encrypt(iv, data, aad)
    tag = ciphertext[-16:]  # GCM 默认在密文末尾附加 16 字节 tag
    cipher_without_tag = ciphertext[:-16]

    # HEX 编码输出
    out_hex = hex_encode(cipher_without_tag)
    tag_hex = hex_encode(tag)
    return out_hex, tag_hex


def aes256_gcm_decrypt(hex_input: str, key: bytes, iv: bytes, aad: bytes = None, hex_tag: str = None):
    aesgcm = AESGCM(key)

    # 解码输入
    ciphertext = hex_decode(hex_input)
    tag = hex_decode(hex_tag)
    full_ciphertext = ciphertext + tag  # 合并密文和tag

    try:
        plaintext = aesgcm.decrypt(iv, full_ciphertext, aad)
        return plaintext
    except Exception as e:
        print("Decryption failed:", e)
        return None
