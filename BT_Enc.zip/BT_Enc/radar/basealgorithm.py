import base64
import os
import re
import shutil
import socket
import zipfile
from datetime import datetime
from typing import List


def hex_to_signed_decimal(hex_string):
    # 将十六进制字符串转换为无符号整数
    unsigned_value = int(hex_string, 16)
    # 假设是8位整数（一个字节），将无符号整数转换为有符号整数
    signed_value = unsigned_value if unsigned_value < 0x80 else unsigned_value - 0x100
    return signed_value


def hex_to_ascii(hex_string):
    # 将十六进制字符串转换为字节数组
    bytes_object = bytes.fromhex(hex_string)
    try:
        # 将字节数组转换为ASCII字符串
        ascii_string = bytes_object.decode("ASCII")
        return ascii_string
    except UnicodeDecodeError:
        # 将字节数组转换为字符串
        ascii_string = bytes_object.decode("UTF-8")
        return ascii_string
    except Exception as e:
        pass
        # logger.error(f'hex_to_ascii {str(e)}')


# 转换为16进制hax
def ascii_to_hex(as_string):
    try:
        return ''.join(format(ord(char), '02x') for char in as_string)
    except Exception as e:
        pass
        # logger.error(f'ascii_to_hex {str(e)}')


def hex_to_bytearray(hex_str):
    """将十六进制字符串转换为bytearray"""
    return bytearray(int(hex_str[i:i+2], 16) for i in range(0, len(hex_str), 2))


# 从列表中获取指定名字
def get_name_from(name: str, nl: List):
    for n in nl:
        if name in n:
            return n
    return ''


# 解压并返回文件名列表
def unzip_file_chunked(zip_file_path, chunk_size=10240 * 1024):
    """
    分块解压 .zip 文件到指定目录

    :param zip_file_path: .zip 文件路径
    :param extract_to_path: 解压到的目标目录
    :param chunk_size: 每次读取的块大小（字节），默认1MB

    """
    extract_to_path = os.path.join(os.getcwd(), 'temp')
    if os.path.exists(extract_to_path):
        # 删除文件夹
        try:
            shutil.rmtree(extract_to_path)
            pass
            # logger.debug(f"Deleted directory: {extract_to_path}")
        except Exception as e:
            pass
            # logger.debug(f"Failed to delete {extract_to_path}. Reason: {e}")

        # 创建文件夹
    os.makedirs(extract_to_path)

    # logger.debug(f"Created directory: {extract_to_path}")

    file_list = []
    with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
        file_list.extend(zip_ref.namelist())
        for file_info in zip_ref.infolist():
            file_path = os.path.join(extract_to_path, file_info.filename)
            if file_info.is_dir():
                os.makedirs(file_path, exist_ok=True)
            else:
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                with zip_ref.open(file_info) as source, open(file_path, 'wb') as target:
                    while True:
                        chunk = source.read(chunk_size)
                        if not chunk:
                            break
                        target.write(chunk)
                # logger.error(f"解压完成: {file_path}")

    # 文件名中异常字符串的处理, mv操作
    for fi in range(len(file_list)):
        fw_temp_path = file_list[fi]
        if '%28' in fw_temp_path and '%29' in fw_temp_path:
            src_path = os.path.join(extract_to_path, fw_temp_path)
            target_path = fw_temp_path.replace('%28', '_').replace('%29', '')
            shutil.copyfile(
                src=src_path,
                dst=os.path.join(extract_to_path, target_path)
            )
            os.remove(src_path)
            file_list[fi] = target_path

    return file_list, extract_to_path


# 比对版本 大于才有用
def is_least_version(ver_min, ver_now) -> bool:
    try:
        v_min = list(map(int, ver_min.split('.')))
        v_now = list(map(int, ver_now.split('.')))

        for i in range(min(len(v_min), len(v_now))):
            if v_now[i] < v_min[i]:
                return False
            if v_now[i] > v_min[i]:
                return True

        # 如果 v_now 的前缀部分与 v_min 相等，检查 v_now 是否更长
        return len(v_now) >= len(v_min)
    except Exception as e:
        # logger.error(f"is_least_version {str(e)}")
        pass

# ssh 下发数据
def encode_cmd(dev_name='Yuka-MNYHEFUU', cmd_str='/etc/init.d/dropbear start') -> str:
    contact_name = dev_name[9:] + dev_name[:9]
    # Base64 编码
    base64_dev_name = base64.b64encode(contact_name.encode()).decode()
    contact_name = base64_dev_name[4:] + base64_dev_name[:4]

    # 构建命令字符串并进行 Base64 编码
    base64_cmd_str = f'{{"id":"1","magic":"{contact_name}","type":"syscmd","cmd":"{cmd_str}"}}'
    return base64_cmd_str


# 判断端口是否占用
def is_port_in_use(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    try:
        s.bind(('127.0.0.1', port))
        return False  # 如果成功绑定，则端口未被占用
    except socket.error:
        return True  # 如果绑定失败，则端口已被占用
    finally:
        s.close()  # 关闭 socket 连接


# 10转16
def decimal_to_hex(decimal_number):
    """Convert a decimal number to a hexadecimal string."""
    if not isinstance(decimal_number, int):
        raise ValueError("Input must be an integer.")

    hex_string = hex(decimal_number)[2:].zfill(4)  # Convert to hex and pad with zeros if needed
    return hex_string.upper()


# 获取16的高低未
def get_high_low(hex_string):
    """Get the high and low bytes from a hexadecimal string."""
    if len(hex_string) != 4:
        raise ValueError("Hex string must be 4 characters long.")

    high_byte = hex_string[:2]
    low_byte = hex_string[2:]
    return high_byte, low_byte


def seconds_to_hms_compact(seconds):
    """
    输入秒，计算时分秒输出：02:01:05
    seconds: 单位是秒
    return:
    """
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}"


def get_tiem_now():
    """
    获取当前的年月日时分秒
    :return:年-月-日-时-分-秒
    """
    now = datetime.now()
    formatted_time = now.strftime("%y-%m-%d-%H-%M-%S")
    return formatted_time


def to_int32_hex(n):
    """
    将数值转换成int32十六进制格式字符串
    """
    return "{:08x}".format(n & 0xFFFFFFFF)


def get_str_key_var(parm: str):
    """
    提取字符串中的键值对
    :param parm: 目标字符串
    :return:
    """
    # 正则表达式匹配键值对
    pattern = re.compile(r'(?P<key>\w+)\s*:\s*(?P<value>[+-]?\d+\.?\d*)')
    # 使用 re.findall 提取所有键值对
    matches = pattern.finditer(parm)
    # 格式化结果：将数值限制为小数点后两位
    return {m.group('key'): float(m.group('value')) for m in matches}


def parse_log(log_str):
    """
    提取键值对
    :param log_str:
    :return:
    """
    pattern = r'(\w+):\s*([^,\s]+)'
    matches = re.findall(pattern, log_str)

    result = {}
    for key, value in matches:
        # 自动转换数字类型
        result[key] = float(value) if '.' in value else int(value) if value.isdigit() else value

    return result
