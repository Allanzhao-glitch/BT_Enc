# --------------------------------------
# Created by Milo on 2025/3/18
# Project: app_maintain
# Desc: 纯蓝牙连接
# --------------------------------------
import binascii
import threading
import traceback
import keyboard
from time import sleep
from typing import Union
import aes256
from bleak import BleakClient, BleakScanner, BLEDevice
import struct
import asyncio
import edch_ble

from basealgorithm import decimal_to_hex, get_high_low
from protobuf_msg import MessagePB, wheel_forward, wheel_stop, wheel_backward

BLUE_SERVICE_UUID = "0000ffff-0000-1000-8000-00805f9b34fb"
BLUE_WRITE_CHAR_UUID = "0000ff01-0000-1000-8000-00805f9b34fb"
BLUE_NOTIF_CHAR_UUID = "0000ff02-0000-1000-8000-00805f9b34fb"
BLUE_NOTIF_DESC_UUID = "00002902-0000-1000-8000-00805f9b34fb"

# ble_mac = 'F0:9E:9E:23:53:1E' #基站
ble_mac = 'CC:64:1A:49:33:73' #车
is_connect = False
iv = bytearray([
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f
])

key = bytearray([
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
    0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A,
    0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54,
    0x55, 0x56
])


data_key = bytearray()

aad = b"Additional authenticated data"

communication_stage = 0
privateKey = edch_ble.generate_ecdh_key()


def send_key_change_data(data):
    global communication_stage
    is_change = 50
    hex_encode = aes256.aes256_encrypt(data, key, iv)
    data = bytes.fromhex(hex_encode)
    client_pub_len = len(data)
    print(hex_encode)
    if communication_stage == 1:
        is_change = 20
    header = struct.pack('BB', client_pub_len, is_change)
    struct_data = header + data
    # self.loop.call_soon_threadsafe(self.write_queue.put_nowait, struct_data)
    blue.send_data(struct_data)
    sleep(1)


class BleakClientThread(threading.Thread):
    FLAG = 'BleakClientThread'

    def __init__(self, address_or_ble_device: Union[BLEDevice, str] = ble_mac):
        super().__init__()
        self.send_sequence = 0
        self.client = BleakClient(address_or_ble_device)
        self.loop = asyncio.new_event_loop()
        self.stop_event = asyncio.Event()
        self.write_queue = asyncio.Queue()
        # 当前已经存的长度
        self.already_len = None
        # 当前的片计数
        self.cont = None
        # 需要拼包的总长的，第一次进入时赋值
        self.total_length = None
        # 拼包数据
        self.pack_data = []
        self.pack_flag = False
        self.last_seq = None

    def run(self):
        try:
            asyncio.set_event_loop(self.loop)
            self.loop.run_until_complete(self.main())
        except Exception as e:
            pass
        finally:
            # Clean up loop resources
            self.loop.run_until_complete(self.loop.shutdown_asyncgens())
            self.loop.close()

    async def main(self):
        try:
            global is_connect
            await self.client.connect()
            for service in self.client.services:
                # logger.error(
                #     '-----------------service uuid: {} [{}]---------------------'.format(service.uuid,
                #                                                                          service.description))
                for c in service.characteristics:
                    pass
            await self.client.start_notify(BLUE_NOTIF_CHAR_UUID, self.notification_handler)
            print(f'connect {ble_mac}')
            is_connect = True
            # MainSignal.get_instance().manage_client_connected.emit(True)
            while not self.stop_event.is_set():
                try:
                    data = await asyncio.wait_for(self.write_queue.get(), timeout=1.0)
                    if data is None:
                        break
                    await self.client.write_gatt_char(BLUE_WRITE_CHAR_UUID, data)
                    # print(BLUE_WRITE_CHAR_UUID, data)
                except asyncio.TimeoutError:
                    continue  # Timeout is expected, continue the loop
        except Exception as e:
            pass
            # logger.error(f"{self.FLAG}, connection or notification error: {str(e)}")
        finally:
            try:
                await self.client.disconnect()
                # logger.error(f"{self.FLAG}, Bluetooth disconnected")
            except Exception as e:
                print(f"disconnect {ble_mac}")
                # logger.error(f"{self.FLAG}, disconnect error: {str(e)}")
            # MainSignal.get_instance().manage_client_connected.emit(False)

    # 第一次收到14帧序号，进行初始拼包操作
    def inti_merge_data(self, data):
        self.pack_data.clear()
        high = data[0:2]
        low = data[2:4]
        self.total_length = int(low + high, 16) * 2
        self.pack_data.append(data[4:])
        self.already_len = len(data[4:])
        self.pack_flag = True

    # 拼包0x14
    def dispose_0x14(self, msg_type, fc, data):
        if not self.pack_flag and fc == '14':
            self.inti_merge_data(data)
        elif fc == '14':  # 第二次来的还是14 就进行检查是否为上一帧的后续，如果不是，就当第一次14帧处理
            temp_height = data[0:2]
            temp_low = data[2:4]
            temp_len = int(temp_low + temp_height, 16) * 2

            if self.total_length != temp_len + self.already_len:
                self.inti_merge_data(data)
            else:
                self.pack_data.append(data[4:])
                self.already_len += len(data[4:])
        else:
            temp_len = len(data)
            if self.total_length == self.already_len + temp_len:
                real_data = ''
                for str_data in self.pack_data:
                    real_data += str_data
                real_data += data
                self.pack_flag = False
                # MainSignal.get_instance().manage_data_received.emit(msg_type, real_data)
                self.pack_data.clear()
            else:
                self.dispose_0x04(msg_type, data)

    # 直接丢出0x04
    def dispose_0x04(self, msg_type, data):
        # pass
        print(msg_type)

    def notification_handler(self, sender, data_t):
        try:
            global communication_stage
            global privateKey
            global data_key
            if communication_stage == 0:
                fmt = '!BB'  # 网络字节序，两个无符号字节
                fixed_size = struct.calcsize(fmt)
                # 解包前两个字段
                client_pub_len, is_change = struct.unpack_from(fmt, data)
                print(client_pub_len, is_change)
                # 计算数据部分长度
                data_start = fixed_size
                data_end = data_start + client_pub_len
                # 提取柔性数组数据
                data = data[data_start:data_end]
                hex_data = data.decode('latin-1')
                # print(hex_data)
                server_pub_key = aes256.aes256_decrypt(hex_data,key,iv)
                print(f"Decrypted: {bytes.hex(server_pub_key)}")
                data_key = edch_ble.compute_shared_secret(privateKey,server_pub_key)
                communication_stage = 1
                send_key_change_data(iv)
                return
            elif communication_stage == 1:
                # data_len, tag_len = struct.unpack('>II', data_t[:8])
                data_start = 8
                # encrypted_data = data[data_start: data_start + data_len]
                # tag = data[data_start + data_len: data_start + data_len + tag_len]
                # encrypted_data = encrypted_data.decode('latin-1')
                # tag = tag.decode('latin-1')
                # data = aes256.aes256_gcm_decrypt(encrypted_data, data_key, iv, aad, tag)
                # data_t = bytes(data).hex()
                lo = ' '.join([data_t[i:i + 2] for i in range(0, len(data_t), 2)])
                # print(lo)
                msg_type = data_t[0:2]
                fc = data_t[2:4]
                seq = data_t[4:6]
                data_len = data_t[6:8]

                data_protobuf = data_t[8:]

                if msg_type == '3d':
                    return
                # if msg_type != '4d':
                #     print(lo)

                if fc == '14' or self.pack_flag:
                    self.dispose_0x14(msg_type, fc, data_protobuf)
                else:
                    self.dispose_0x04(msg_type, data_protobuf)
        except Exception:
            traceback.print_exc()

    # 获取计数
    def get_send_num(self):
        self.send_sequence += 1
        self.send_sequence = self.send_sequence & 0xFF
        return self.send_sequence

    def send_data(self, obj: object):
        global data_key
        seqs = self.get_send_num()
        data = None
        # TODO
        if isinstance(obj, MessagePB):
            data = obj.create_msg()
        else:
            data = obj
            # return

        while True:
            data_len = len(data)
            if data_len == 0:
                break
            if data_len > 100:
                head = [77, 20, seqs, 102]
                hex_st = decimal_to_hex(data_len)
                high_byte, low_byte = get_high_low(hex_st)
                low_byte = int(low_byte, 16)
                head.append(low_byte)
                high_byte = int(high_byte, 16)
                head.append(high_byte)
                head.extend(data[0:100])
                data = data[100:]
                send_data = bytearray(head)
                seqs = self.get_send_num()
            else:
                len_data = len(data)
                head = [77, 0, seqs, len_data]
                head.extend(data)
                send_data = bytearray(head)
                data = ''
            hx = send_data.hex()
            if not self.loop.is_closed():
                # hex_data = aes256.aes256_encrypt(send_data, key, iv) #CBD加密数据
                # print(f" send data: {' '.join([hex_data[i:i + 2] for i in range(0, len(hex_data), 2)])}")
                # out_hex, tag_hex = aes256.aes256_gcm_encrypt(send_data, data_key, iv, aad)  # GCM加密数据
                # out_data = bytes.fromhex(out_hex)
                # tag_data = bytes.fromhex(tag_hex)
                # packed_data = struct.pack(f'!II{len(out_data)}s16s', len(out_data), len(tag_data), out_data,
                #                           tag_data)  # 封包
                # print("out_hex " + out_hex)
                # print("tag_hex " + tag_hex)
                print(f" send data: {' '.join([hx[i:i + 2] for i in range(0, len(hx), 2)])}")

                self.loop.call_soon_threadsafe(self.write_queue.put_nowait, hx)

    def send_wifi_cntrl(self, msg_type, msg_data):
        seqs = self.get_send_num()
        if msg_data is None:
            head = [msg_type, 0, seqs, 0]
        else:
            head = [msg_type, 0, seqs, len(msg_data)]
            head.extend(msg_data)
        send_data = bytearray(head)
        hx = send_data.hex()
        # logger.debug(f"send data: {' '.join([hx[i:i + 2] for i in range(0, len(hx), 2)])}")
        if not self.loop.is_closed():
            self.loop.call_soon_threadsafe(self.write_queue.put_nowait, send_data)

    def is_alive(self):
        if self.client:
            return self.client.is_connected
        return False

    def stop(self):
        try:
            self.loop.call_soon_threadsafe(self.write_queue.put_nowait, None)
            self.loop.call_soon_threadsafe(self.stop_event.set)
        except Exception as e:
            pass
            # logger.error(f'{self.FLAG} stop error: {str(e)}')


def key_ctrl():
    try:
        # 绑定按键
        if keyboard.is_pressed('up'):
            blue.send_data(wheel_forward())
            print("Forward command sent")
            sleep(0.3)  # 防止重复触发

        elif keyboard.is_pressed('down'):
            blue.send_data(wheel_backward())
            print("Backward command sent")
            sleep(0.3)

        elif keyboard.is_pressed('space'):
            blue.send_data(wheel_stop())
            print("Stop command sent")
            sleep(0.3)

        elif keyboard.is_pressed('esc'):
            print("Exiting...")

    except Exception as e:
        print(f"Keyboard error: {e}")


def key_exchange():
    global communication_stage
    global privateKey
    pub_bytes = edch_ble.export_public_key(privateKey)  # 生成公钥
    send_key_change_data(pub_bytes)


if __name__ == '__main__':
    blue = BleakClientThread()
    blue.start()
    while True:
        if is_connect:
            if communication_stage == 0:
                key_exchange()
                # break


    while True:
        if is_connect:
            if communication_stage == 1:
                key_ctrl()

