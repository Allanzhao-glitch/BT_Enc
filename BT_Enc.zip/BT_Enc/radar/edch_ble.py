from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import binascii

# 曲线名称 (NIST P-256)
CURVE = ec.SECP256R1()


def generate_ecdh_key():
    """
    生成ECDH密钥对
    返回: 私钥对象
    """
    private_key = ec.generate_private_key(CURVE, default_backend())
    # 验证密钥有效性
    public_key = private_key.public_key()
    if not public_key.public_numbers():
        raise ValueError("Invalid key generated")
    print("BLE Key pair generated successfully")
    return private_key


def export_public_key(private_key):
    """
    导出压缩格式的公钥
    参数: private_key - 私钥对象
    返回: 压缩格式公钥字节串
    """
    public_key = private_key.public_key()
    # 导出压缩格式公钥
    public_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.CompressedPoint
    )
    print(f"BLE Public key exported successfully len:{len(public_bytes)}")
    return public_bytes


def compute_shared_secret(local_private_key, peer_pub_bytes):
    """
    计算共享密钥
    参数:
        local_private_key: 本地私钥对象
        peer_pub_bytes: 对端压缩公钥字节串
    返回: 共享密钥字节串
    """
    # 从字节导入对端公钥
    try:
        peer_public_key = ec.EllipticCurvePublicKey.from_encoded_point(
            CURVE, peer_pub_bytes
        )
    except Exception as e:
        print(f"BLE Error: Failed to parse public key - {str(e)}")
        return None

    # 验证对端公钥在曲线上
    if not peer_public_key.public_numbers():
        print("BLE Error: Peer public key is not on curve")
        return None

    # 计算共享密钥
    try:
        shared_secret = local_private_key.exchange(ec.ECDH(), peer_public_key)
        print(f"BLE Success: Shared secret computed (len={len(shared_secret)})")
        return shared_secret
    except Exception as e:
        print(f"BLE Error: ECDH computation failed - {str(e)}")
        return None


# 示例用法
if __name__ == "__main__":
    # Alice生成密钥对并导出公钥
    alice_priv = generate_ecdh_key()
    alice_pub = export_public_key(alice_priv)

    # Bob生成密钥对并导出公钥
    bob_priv = generate_ecdh_key()
    bob_pub = export_public_key(bob_priv)

    # Alice计算共享密钥
    alice_shared = compute_shared_secret(alice_priv, bob_pub)

    # Bob计算共享密钥
    bob_shared = compute_shared_secret(bob_priv, alice_pub)

    # 验证共享密钥相同
    if alice_shared and bob_shared and alice_shared == bob_shared:
        print("Shared secrets match!")
        print("Shared Key:", binascii.hexlify(alice_shared).decode())
    else:
        print("Shared secrets do not match!")