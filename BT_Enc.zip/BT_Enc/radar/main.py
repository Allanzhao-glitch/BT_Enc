import serial
import binascii
import time

# 设置串口号和波特率
port = 'COM5'
baudrate = 19200

one_arr = [None] * 10
one_len = 0
two_arr = [None] * 10
two_len = 0
three_arr = [None] * 10
three_len = 0

## 平均值滤波
def median_average_filter(data):
    max = 0
    min = 0
    sum = 0
    count = 0
    max_value_count = 0
    for i in range(0, 10):
        if data[i] >= 250:
            max_value_count += 1
            continue
        if data[i] == 0:
            count += 1
        if data[i] >= max:
            max = data[i]
        if data[i] <= min:
            min = data[i]
        sum += data[i]
    if count > 5:
        return 0
    if max_value_count >= 5:
        return 0
    if count >= 1:
        count -= 1
    # print("count:", str(count), "max_value_count:", str(max_value_count))
    sum = sum - max - min
    if 10 - 2 - count - max_value_count == 0:
        return 0
    return sum // (10 - 2 - count - max_value_count)

## 串口数据
def serial_data_del(data):
    global one_len
    global one_arr
    global two_arr
    global two_len
    global three_arr
    global three_len
    one = data[2] + data[3]
    two = data[4] + data[5]
    three = data[6] + data[7]
    # print(one, two, three)
    # print(int(one, 16), int(two, 16), int(three, 16))
    if one_len != 10:
        one_arr[one_len] = int(one, 16)
        one_len += 1
    elif one_len == 10:
        one_len = 0
        print("一号探头：" + str(median_average_filter(one_arr)) + "cm")
    if two_len != 10:
        two_arr[two_len] = int(two, 16)
        two_len += 1
    elif two_len == 10:
        two_len = 0
        print("二号探头：" + str(median_average_filter(two_arr)) + "cm")
    if three_len != 10:
        three_arr[three_len] = int(three, 16)
        three_len += 1
    elif three_len == 10:
        three_len = 0
        print("三号探头:" + str(median_average_filter(three_arr)) + "cm")


def get_serial():
    # 打开串口
    ser = serial.Serial(port=port, baudrate=baudrate, timeout=1)

    if ser.is_open:
        try:
            while True:
                data = ser.read(12)
                if data:
                    hex_data = binascii.hexlify(data).decode('utf-8')
                    serial_data_del(hex_data)
        except KeyboardInterrupt:
            pass
        finally:
            ser.close()
    else:
        print("无法打开串口")


if __name__ == '__main__':
    get_serial()
