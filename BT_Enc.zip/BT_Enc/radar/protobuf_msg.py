# --------------------------------------
# Created by Milo on 2025/3/18
# Project: app_maintain
# Desc: 这个文件是用来组合下发指令的
# --------------------------------------
import base64
import threading
from datetime import datetime
from enum import Enum
from typing import Union

from google.protobuf.json_format import MessageToDict
from pb import dev_net_pb2, mctrl_sys_pb2, Luba_msg_pb2, pdt_pb2, mctrl_nav_pb2, mctrl_driver_pb2


class ProtoBufType(Enum):
    PROTOBUF = 0
    MASGBUS = 1


# 消息的发送
class MessagePB(object):
    _count = 0
    _lock = threading.RLock()  # 改用可重入锁（引用[1]原理）

    @classmethod
    def get_seqs(cls):
        with cls._lock:
            # 显式执行三步操作确保原子性
            current = cls._count
            current += 1
            cls._count = current
        return cls._count

    def __init__(self, seqs: int, recv: int = 0, work_type: ProtoBufType = ProtoBufType.PROTOBUF):
        """
        初始化
        :param recv: 接收者
        :param work_type: 实列生成消息的类型
        """
        self.__head = None
        self.__msgtype = None
        self.__msgattr = None
        self.__sender = None
        self.__sub_msg = None
        self.__sub_cmd = None
        self.__cmd = None
        self.__data_len = None
        self.__data = None
        self.__seqs = seqs
        self.__classify = None
        self.__oneof = None
        self.__msgbus_pkt = None
        self.__work_type = work_type
        self.__recv = recv
        self.__luba_msg = Luba_msg_pb2.LubaMsg()

    def get_print(self):
        print(self.__seqs, self.__msgtype, self.__msgattr, self.__sub_cmd, self.__cmd)

    def set_msgtype(self, parm: int):
        """
        设置消息类型
        :param parm: protobuf 中的 MsgCmdType 消息类型
        :return: 本身
        """
        self.__msgtype = parm
        return self

    def set_msgAttr(self, parm: int):
        """
        设置消息的属性，
        :param parm: 请求，回复，报告，无 protobuf 中的MsgAttr
        :return:
        """
        self.__msgattr = parm
        return self

    def set_lubasubmsg(self, parm):
        """
        添加已经写好的子protobuf
        :param parm: 其他protobuf类实列
        :return:
        """
        self.__sub_msg = parm
        return self

    def set_cmd(self, cmd: int, sub_cmd: int, tar: int):
        """
        msgbus的指令和子指令
        :param cmd: 命令
        :param sub_cmd: 子命令
        :param tar: 转发接收者
        :return:
        """
        self.__cmd = cmd
        self.__sub_cmd = sub_cmd
        self.__msgbus_pkt = tar
        return self

    def set_data(self, parm: str):
        """
        msgbus的数据
        :param parm: 下发数据
        :return:
        """
        if parm is None:
            return
        self.__data = parm
        self.__data_len = len(self.__data)
        return self

    def create_msg(self) -> bytearray:
        """
        创建出消息字节数组
        :return:
        """
        try:
            self.__luba_msg.msgtype = self.__msgtype
            self.__luba_msg.sender = Luba_msg_pb2.DEV_MOBILEAPP
            self.__luba_msg.rcver = self.__recv
            self.__luba_msg.msgattr = self.__msgattr
            self.__luba_msg.seqs = self.__seqs
            self.__luba_msg.version = 1
            self.__luba_msg.subtype = 1
            self.__luba_msg.timestamp = 1
            if self.__work_type == ProtoBufType.PROTOBUF:
                # TODO 后续如果需要发送其他消息可在这里添加
                if self.__msgtype == 0xf4:
                    self.__luba_msg.sys.CopyFrom(self.__sub_msg)
                elif self.__msgtype == 0xf3:
                    self.__luba_msg.driver.CopyFrom(self.__sub_msg)
                elif self.__msgtype == 0xf8:
                    self.__luba_msg.net.CopyFrom(self.__sub_msg)
                elif self.__msgtype == 0xf0:
                    self.__luba_msg.nav.CopyFrom(self.__sub_msg)
                elif self.__msgtype == 0XfC:
                    self.__luba_msg.pdt.CopyFrom(self.__sub_msg)
            elif self.__work_type == ProtoBufType.MASGBUS:
                ctrl_sys = mctrl_sys_pb2.MctlSys()
                msgbus_pkt = mctrl_sys_pb2.msgbus_pkt()
                msgbus_pkt.sendDeviceId = Luba_msg_pb2.DEV_MOBILEAPP
                msgbus_pkt.recvDeviceId = self.__msgbus_pkt
                msgbus_pkt.type = self.__cmd
                msgbus_pkt.typeCommand = self.__sub_cmd
                if self.__data:
                    msgbus_pkt.dataLength = self.__data_len
                    byte_data = self.__data.encode('utf-8')  # 字节序列
                    base64_data = base64.b64encode(byte_data)
                    msgbus_pkt.data = base64_data.decode('utf-8')
                else:
                    msgbus_pkt.dataLength = 0
                    msgbus_pkt.data = ''
                msgbus_pkt.seqs = self.__seqs
                ctrl_sys.to_dev_msgbus.CopyFrom(msgbus_pkt)
                self.__luba_msg.sys.CopyFrom(ctrl_sys)
            return self.__luba_msg.SerializeToString()
        except Exception as e:
            pass
            # logger.error(f'create_msg {str(e)}')

    # @property
    # def msg_classify(self) -> str:
    #     """
    #     生成信息的id，用于发送
    #     :return:
    #     """
    #
    #     if self.__classify is None:
    #         self.__classify = f'0x07{self.__recv if self.__work_type == ProtoBufType.PROTOBUF else self.__msgbus_pkt:02X}{self.__msgtype:02X}{to_int32_hex(self.__seqs)}'
    #     return self.__classify

    # def rcv_msg(self, msg_type: str,  data):
    #     """
    #     收到数据解析
    #     :param msg_type:
    #     :param data:
    #     :return:
    #     """
    #     try:
    #         if msg_type == '4d':
    #             self.__head = '4d'
    #             self.__luba_msg.ParseFromString(bytes.fromhex(data))
    #             self.__seqs = self.__luba_msg.seqs
    #             self.__sender = self.__luba_msg.sender
    #             self.__msgtype = self.__luba_msg.msgtype
    #             if self.__luba_msg.msgtype == Luba_msg_pb2.MSG_CMD_TYPE_ESP:
    #                 self.__data = self.__luba_msg.net
    #                 self.__oneof = self.__luba_msg.net.WhichOneof('NetSubType')
    #             elif self.__luba_msg.msgtype == Luba_msg_pb2.MSG_CMD_TYPE_PDT_PB:
    #                 self.__data = self.__luba_msg.pdt
    #                 self.__oneof = self.__luba_msg.pdt.WhichOneof('SubPdtType')
    #             elif self.__luba_msg.msgtype == Luba_msg_pb2.MSG_CMD_TYPE_EMBED_SYS:
    #                 self.__oneof = self.__luba_msg.sys.WhichOneof('SubSysMsg')
    #                 if self.__oneof == 'to_app_msgbus':
    #                     self.__data = self.__luba_msg.sys.to_app_msgbus.data
    #                     self.__cmd = self.__luba_msg.sys.to_app_msgbus.type
    #                     self.__sub_cmd = self.__luba_msg.sys.to_app_msgbus.typeCommand
    #                 else:
    #                     self.__data = self.__luba_msg.sys
    #             elif self.__luba_msg.msgtype == Luba_msg_pb2.MSG_CMD_TYPE_NAV:
    #                 self.__data = self.__luba_msg.nav
    #                 self.__oneof = self.__luba_msg.nav.WhichOneof('SubNavMsg')
    #         elif msg_type == '45':
    #             self.__head = '45'
    #             wifi_list = {}
    #             while data:
    #                 # 长度等于 ssid + rssi 的长的度
    #                 msg_len = data[0:2]
    #                 msg_len = int(msg_len, 16)
    #                 rssi = data[2:4]
    #                 ssid = data[4:(msg_len + 1) * 2]
    #                 wifi_list.update({hex_to_ascii(ssid): hex_to_signed_decimal(rssi)})
    #                 data = data[(msg_len + 1) * 2:]
    #             self.__data = wifi_list
    #     except Exception as e:
    #         # logger.error(f"rcv_msg {str(e)}")
    #     finally:
    #         return self

    # def rec_classify(self) -> str:
    #     """
    #     生成信息的id，用于接收对比
    #     :return:
    #     """
    #     if self.__head == '4d':
    #         return f"0x07{self.__sender:02X}{self.__msgtype:02X}{to_int32_hex(self.__seqs)}"
    #     elif self.__head == '45':
    #         return self.__head

    def rcv_oneof(self):
        """
        返回当前消息包含的结构名称
        :return:
        """
        return self.__oneof

    def rec_data(self):
        """
        返回解析后的数据
        :return:
        """
        if self.__oneof == 'to_app_msgbus':
            byte_data = self.__data.encode('utf-8', 'ignore')
            base64_data = base64.b64decode(byte_data)
            r = base64_data.hex()
            return base64_data.decode('utf-8', 'ignore')
        else:
            return self.__data

    def rcv_cmd(self):
        """
        用于内包msgbus 区分消息
        :return:
        """
        return self.__cmd

    def rcv_sub_cmd(self):
        """
        用于内包msgbus 区分消息
        :return:
        """
        return self.__sub_cmd


def wheel_forward(parm: float = 1):
    """
    车轮正转
    :return:
    """
    if parm < 0.2 or parm > 1.2:
        return
    # msg = MsgProtoBuf(receiver=1)
    # msg.set_cmd(130)
    # msg.set_cmd_sub(24)
    # msg.set_data(f'wheelSet {parm} 0')
    msg = MessagePB(seqs=1, recv=13, work_type=ProtoBufType.MASGBUS).set_msgtype(
        0xf4).set_msgAttr(1)
    msg.set_cmd(130, 24, 1).set_data(f'wheelSet {parm} 0')
    return msg


def wheel_backward(parm: float = 1):
    """
    车轮反转
    :return:
    """
    print(parm)
    if parm < 0.2 or parm > 1.2:
        return
    # msg = MsgProtoBuf(receiver=1)
    # msg.set_cmd(130)
    # msg.set_cmd_sub(24)
    # msg.set_data(f'wheelSet -{parm} 0')
    msg = MessagePB(seqs=1, recv=13, work_type=ProtoBufType.MASGBUS).set_msgtype(
        0xf4).set_msgAttr(1)
    msg.set_cmd(130, 24, 1).set_data(f'wheelSet -{parm} 0')
    print(msg)
    return msg


def wheel_stop():
    """
    停止车轮
    :return:
    """
    # msg = MsgProtoBuf(receiver=1)
    # msg.set_cmd(130)
    # msg.set_cmd_sub(24)
    # msg.set_data('wheelSet 0 0')
    msg = MessagePB(seqs=1, recv=13, work_type=ProtoBufType.MASGBUS).set_msgtype(
        0xf4).set_msgAttr(1)
    msg.set_cmd(130, 24, 1).set_data("wheelSet 0 0")
    return msg


def isPdtMod():
    # msg = MsgProtoBuf(receiver=15)
    # msg.set_cmd(83)
    # msg.set_cmd_sub(2)
    msg = MessagePB(seqs=1, recv=13, work_type=ProtoBufType.MASGBUS).set_msgtype(
        0xf4).set_msgAttr(1)
    msg.set_cmd(83, 2, 15)
    return msg
