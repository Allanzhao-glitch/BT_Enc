from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import binascii


def aes256_encrypt(input_text, key, iv):
    # 创建一个AES cipher对象
    cipher = AES.new(key, AES.MODE_CBC, iv)

    # 对输入文本进行填充并加密
    padded_data = pad(input_text.encode(), AES.block_size)
    ciphertext = cipher.encrypt(padded_data)

    # 将加密后的字节转换为十六进制表示
    out_hex = binascii.hexlify(ciphertext).decode('utf-8')
    return out_hex


def aes256_decrypt(hex_input, key, iv):
    # 将十六进制字符串转换回字节
    ciphertext = binascii.unhexlify(hex_input)

    # 创建一个AES cipher对象
    cipher = AES.new(key, AES.MODE_CBC, iv)

    # 解密并去除填充
    plaintext_padded = cipher.decrypt(ciphertext)
    plaintext = unpad(plaintext_padded, AES.block_size)
    return plaintext


# 示例用法
iv = bytearray([
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
    0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f
])

key = bytearray([
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39,
    0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A,
    0x4B, 0x4C, 0x4D, 0x4E, 0x4F, 0x50, 0x51, 0x52, 0x53, 0x54,
    0x55, 0x56
])
input_text = "cf8cdc6a8ab6f69e47367352b38b2f268f2632c4c401e4942d84aedb1ae3b631"

encrypted = aes256_encrypt(input_text, key, iv)
print(f"Encrypted: {encrypted}")

decrypted = aes256_decrypt(input_text, key, iv)
print(f"Decrypted: {bytes.hex(decrypted)}")


